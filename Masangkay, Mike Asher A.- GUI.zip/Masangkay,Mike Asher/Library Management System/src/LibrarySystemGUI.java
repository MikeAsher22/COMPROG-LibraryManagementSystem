import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.border.EmptyBorder;
import java.awt.event.MouseAdapter; // Import MouseAdapter from java.awt.event
import java.awt.event.MouseEvent;

public class LibrarySystemGUI {
    private static List<Book> books = new ArrayList<>();
    private static Map<String, User> users = new HashMap<>();  // Username to User object mapping
    private static User currentUser = null;  // Track the current logged-in user
    private static boolean isAdmin = false;

    private static JTextArea bookListTextArea; // Added for updating book list

    public static void main(String[] args) {
        // Adding initial books
        books.add(new Book("The Little Prince", "Antoine de Saint-Exupery", "9780156012195", "Children's Literature", 113213, 24));
        books.add(new Book("Harry Potter Series", "J.K. Rowling", "9780747532743", "Fantasy", 402157, 48));
        books.add(new Book("Sherlock Holmes Series", "Sir Arthur Conan Doyle", "978-0486474917", "Mystery", 553457, 72));
        books.add(new Book("The Great Gatsby", "F. Scott Fitzgerald", "9780743273565", "Literary Fiction", 105463, 24));
        books.add(new Book("The Descent of Man", "Charles Darwin", "9780140436310", "Non-fiction", 345723, 48));

        // Adding initial users
        users.put("user1", new User("User One", "user1@example.com", "password1", "1234567890"));
        users.put("user2", new User("User Two", "user2@example.com", "password2", "9876543210"));

        // Create main frame
        JFrame frame = new JFrame("Library System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLayout(new CardLayout());

        // Create panels
        JPanel welcomePanel = createWelcomePanel(frame);
        JPanel userPanel = createUserPanel(frame);
        JPanel userLoginPanel = createUserLoginPanel(frame);
        JPanel userSignUpPanel = createUserSignUpPanel(frame);
        JPanel adminPanel = createAdminPanel(frame);
        JPanel bookPanel = createBookPanel(frame);
        JPanel viewBooksPanel = createViewBooksPanel(frame);
        JPanel manageLibraryPanel = createManageLibraryPanel(frame); // New panel for managing library

        frame.add(welcomePanel, "Welcome");
        frame.add(userPanel, "User");
        frame.add(userLoginPanel, "UserLogin");
        frame.add(userSignUpPanel, "UserSignUp");
        frame.add(adminPanel, "Admin");
        frame.add(bookPanel, "Books");
        frame.add(viewBooksPanel, "ViewBooks");
        frame.add(manageLibraryPanel, "ManageLibrary"); // Add manage library panel

        // Show welcome panel initially
        CardLayout cl = (CardLayout) (frame.getContentPane().getLayout());
        cl.show(frame.getContentPane(), "Welcome");

        // Display the frame
        frame.setVisible(true);
    }

    private static JPanel createWelcomePanel(JFrame frame) {
        EmptyBorder emptyBorder = new EmptyBorder(100, 0, 10, 0);
        JPanel welcomePanel = new JPanel(new GridBagLayout());
        welcomePanel.setBackground(Color.decode("#7c0a02")); // Light gray background

        JLabel welcomeLabel = new JLabel("Welcome to the OG LIBRARY!");
        welcomeLabel.setFont(new Font("sansserif", Font.BOLD, 30));
        welcomeLabel.setForeground(new Color(225, 225, 225)); // Dark gray text
        welcomePanel.add(welcomeLabel);
        
        JLabel identityLabel = new JLabel("Who are you?");
        identityLabel.setFont(new Font("sansserif", Font.PLAIN, 18));
        identityLabel.setForeground(Color.decode("#ffffff"));
        identityLabel.setHorizontalAlignment(SwingConstants.CENTER);
        identityLabel.setBorder(emptyBorder);// Dark gray text
        welcomePanel.add(identityLabel);
        
        JButton userButton = createStyledButton("Regular User");
        userButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) (frame.getContentPane().getLayout());
            cl.show(frame.getContentPane(), "UserLogin");
            isAdmin = false;
        });

        JButton adminButton = createStyledButton("Admin");
        adminButton.addActionListener(e -> {
            String code = JOptionPane.showInputDialog(frame, "Enter admin code:");
            if ("123".equals(code)) {
                CardLayout cl = (CardLayout) (frame.getContentPane().getLayout());
                cl.show(frame.getContentPane(), "Admin");
                isAdmin = true;
            } else {
                JOptionPane.showMessageDialog(frame, "Invalid admin code.");
            }
        });

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10); // Adjust insets for spacing

        welcomePanel.add(welcomeLabel, gbc); // Add welcome label
        gbc.gridy++;
        welcomePanel.add(userButton, gbc); // Add user button
        gbc.gridy++;
        welcomePanel.add(adminButton, gbc); // Add admin button

        return welcomePanel;
    }

    private static JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("sansserif", Font.PLAIN, 16));
        button.setBackground(Color.decode("#555555")); // Green background
        button.setForeground(Color.white); // White text
        button.setPreferredSize(new Dimension(200, 40));
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        });       
        return button;
    }

    private static JPanel createUserPanel(JFrame frame) {
        JPanel userPanel = new JPanel(new GridLayout(3, 1));
        userPanel.setBackground(Color.decode("#7c0a02")); // Light gray background

        JLabel userLabel = new JLabel("Choose what do you want to do.", JLabel.CENTER);
        userLabel.setFont(new Font("sansserif", Font.BOLD, 20)); // Larger font

        JButton viewBooksButton = createStyledButton("View Available Books");
        viewBooksButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) (frame.getContentPane().getLayout());
            cl.show(frame.getContentPane(), "ViewBooks");
        });

        JButton userLogOutButton = createStyledButton("Log Out");
        userLogOutButton.addActionListener(e -> {
            currentUser = null;
            isAdmin = false;
            CardLayout cl = (CardLayout) (frame.getContentPane().getLayout());
            cl.show(frame.getContentPane(), "Welcome");
        });

        userPanel.add(userLabel);
        userPanel.add(viewBooksButton);
        userPanel.add(userLogOutButton);

        return userPanel;
    }

  private static JPanel createUserLoginPanel(JFrame frame) {
    JPanel userLoginPanel = new JPanel(new GridBagLayout());
    userLoginPanel.setBackground(Color.decode("#7c0a02")); // Light gray background

    JLabel userLoginLabel = new JLabel("Log In", JLabel.CENTER);
    userLoginLabel.setFont(new Font("sansserif", Font.BOLD, 25));
    userLoginLabel.setForeground(Color.WHITE); // Set font color to white

    Insets insets = new Insets(10, 10, 5, 10);
    JTextField loginUsernameField = new JTextField(30);
    loginUsernameField.setFont(new Font("sansserif", Font.PLAIN, 14));
    loginUsernameField.setBorder(BorderFactory.createCompoundBorder(loginUsernameField.getBorder(), new EmptyBorder(insets)));
    loginUsernameField.setForeground(Color.BLACK); // Set font color to black

    JPasswordField loginPasswordField = new JPasswordField(30);
    loginPasswordField.setFont(new Font("sansserif", Font.PLAIN, 14));
    loginPasswordField.setBorder(BorderFactory.createCompoundBorder(loginPasswordField.getBorder(), new EmptyBorder(insets)));
    loginPasswordField.setForeground(Color.BLACK); // Set font color to black

    JButton loginButton = createStyledButton("Log In");
    loginButton.setForeground(Color.WHITE); // Set font color to white

    JButton switchToSignUpButton = createStyledButton("Sign Up");
    switchToSignUpButton.setForeground(Color.WHITE); // Set font color to white

    GridBagConstraints gbc = new GridBagConstraints();
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = GridBagConstraints.REMAINDER;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.insets = new Insets(10, 10, 10, 10); // Adjust insets for spacing

    userLoginPanel.add(userLoginLabel, gbc); // Add login label
    gbc.gridy++;
    
    // Username label
    JLabel usernameLabel = new JLabel("<html><body><p><b>Username:</b></p></body></html>");
    usernameLabel.setForeground(Color.WHITE); // Set font color to white
    userLoginPanel.add(usernameLabel, gbc);
    
    gbc.gridy++;
    userLoginPanel.add(loginUsernameField, gbc); // Username field
    gbc.gridy++;
    
    // Password label
    JLabel passwordLabel = new JLabel("Password:");
    passwordLabel.setForeground(Color.WHITE); // Set font color to white
    userLoginPanel.add(passwordLabel, gbc);
    
    gbc.gridy++;
    userLoginPanel.add(loginPasswordField, gbc); // Password field
    gbc.gridy++;
    userLoginPanel.add(loginButton, gbc); // Login button
    gbc.gridy++;
    userLoginPanel.add(switchToSignUpButton, gbc); // Switch to sign up button

    loginButton.addActionListener(e -> {
        String username = loginUsernameField.getText();
        String password = new String(loginPasswordField.getPassword());

        if (users.containsKey(username) && users.get(username).getPassword().equals(password)) {
            currentUser = users.get(username);
            JOptionPane.showMessageDialog(frame, "Login Successful");
            if (isAdmin) {
                CardLayout cl = (CardLayout) (frame.getContentPane().getLayout());
                cl.show(frame.getContentPane(), "Admin");
            } else {
                CardLayout cl = (CardLayout) (frame.getContentPane().getLayout());
                cl.show(frame.getContentPane(), "User");
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Invalid username or password.");
        }
    });

    switchToSignUpButton.addActionListener(e -> {
        CardLayout cl = (CardLayout) (frame.getContentPane().getLayout());
        cl.show(frame.getContentPane(), "UserSignUp");
    });

    return userLoginPanel;
}



  private static JPanel createUserSignUpPanel(JFrame frame) {
    JPanel userSignUpPanel = new JPanel(new GridBagLayout());
    userSignUpPanel.setBackground(Color.decode("#7c0a02")); // Light gray background

    JLabel userSignUpLabel = new JLabel("Sign Up", JLabel.CENTER);
    userSignUpLabel.setFont(new Font("sansserif", Font.BOLD, 20));
    userSignUpLabel.setForeground(Color.WHITE); // Set font color to white

    JTextField signUpUsernameField = new JTextField(20);
    signUpUsernameField.setForeground(Color.BLACK); // Set font color to black

    JPasswordField signUpPasswordField = new JPasswordField(20);
    signUpPasswordField.setForeground(Color.BLACK); // Set font color to black

    JTextField signUpEmailField = new JTextField(20);
    signUpEmailField.setForeground(Color.BLACK); // Set font color to black

    JTextField signUpPhoneField = new JTextField(20);
    signUpPhoneField.setForeground(Color.BLACK); // Set font color to black

    JButton signUpButton = createStyledButton("Sign Up");
    signUpButton.setForeground(Color.WHITE); // Set font color to white

    JButton switchToLoginButton = createStyledButton("Log In");
    switchToLoginButton.setForeground(Color.WHITE); // Set font color to white

    GridBagConstraints gbc = new GridBagConstraints();
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = GridBagConstraints.REMAINDER;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.insets = new Insets(5, 5, 5, 5); // Adjust insets for spacing

    userSignUpPanel.add(userSignUpLabel, gbc); // Add sign-up label
    gbc.gridy++;
    
    // Username label
    JLabel usernameLabel = new JLabel("Username:");
    usernameLabel.setForeground(Color.WHITE); // Set font color to white
    userSignUpPanel.add(usernameLabel, gbc);
    
    gbc.gridy++;
    userSignUpPanel.add(signUpUsernameField, gbc); // Username field
    gbc.gridy++;
    
    // Password label
    JLabel passwordLabel = new JLabel("Password:");
    passwordLabel.setForeground(Color.WHITE); // Set font color to white
    userSignUpPanel.add(passwordLabel, gbc);
    
    gbc.gridy++;
    userSignUpPanel.add(signUpPasswordField, gbc); // Password field
    gbc.gridy++;
    
    // Email label
    JLabel emailLabel = new JLabel("Email:");
    emailLabel.setForeground(Color.WHITE); // Set font color to white
    userSignUpPanel.add(emailLabel, gbc);
    
    gbc.gridy++;
    userSignUpPanel.add(signUpEmailField, gbc); // Email field
    gbc.gridy++;
    
    // Phone label
    JLabel phoneLabel = new JLabel("Phone:");
    phoneLabel.setForeground(Color.WHITE); // Set font color to white
    userSignUpPanel.add(phoneLabel, gbc);
    
    gbc.gridy++;
    userSignUpPanel.add(signUpPhoneField, gbc); // Phone field
    gbc.gridy++;
    
    userSignUpPanel.add(signUpButton, gbc); // Sign-up button
    gbc.gridy++;
    userSignUpPanel.add(switchToLoginButton, gbc); // Switch to log in button

    signUpButton.addActionListener(e -> {
        String username = signUpUsernameField.getText();
        String password = new String(signUpPasswordField.getPassword());
        String email = signUpEmailField.getText();
        String phone = signUpPhoneField.getText();

        if (!users.containsKey(username)) {
            users.put(username, new User(username, email, password, phone));
            JOptionPane.showMessageDialog(frame, "User signed up successfully!");
            CardLayout cl = (CardLayout) (frame.getContentPane().getLayout());
            cl.show(frame.getContentPane(), "UserLogin");
        } else {
            JOptionPane.showMessageDialog(frame, "Username already taken.");
        }
    });

    switchToLoginButton.addActionListener(e -> {
        CardLayout cl = (CardLayout) (frame.getContentPane().getLayout());
        cl.show(frame.getContentPane(), "UserLogin");
    });

    return userSignUpPanel;
}


    private static JPanel createAdminPanel(JFrame frame) {
        JPanel adminPanel = new JPanel(new GridLayout(3, 1));
        adminPanel.setBackground(Color.decode("#7c0a02")); // Light gray background

        JLabel adminLabel = new JLabel("Admin Actions", JLabel.CENTER);
        adminLabel.setFont(new Font("sanserrif", Font.BOLD, 20)); // Larger font

        JButton manageLibraryButton = createStyledButton("Manage Library");
        manageLibraryButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) (frame.getContentPane().getLayout());
            cl.show(frame.getContentPane(), "ManageLibrary");
        });

        JButton adminLogOutButton = createStyledButton("Log Out");
        adminLogOutButton.addActionListener(e -> {
            currentUser = null;
            isAdmin = false;
            CardLayout cl = (CardLayout) (frame.getContentPane().getLayout());
            cl.show(frame.getContentPane(), "Welcome");
        });

        adminPanel.add(adminLabel);
        adminPanel.add(manageLibraryButton);
        adminPanel.add(adminLogOutButton);

        return adminPanel;
    }

    private static JPanel createBookPanel(JFrame frame) {
        JPanel bookPanel = new JPanel(new BorderLayout());
        bookPanel.setBackground(Color.decode("#7c0a02")); // Light gray background

        JLabel bookLabel = new JLabel("Books", JLabel.CENTER);
        bookLabel.setFont(new Font("sanserrif", Font.BOLD, 20)); // Larger font

        bookListTextArea = new JTextArea(10, 40); // Initialize the JTextArea
        bookListTextArea.setEditable(false);
        updateBookList();

        JScrollPane scrollPane = new JScrollPane(bookListTextArea);

        JButton backButton = createStyledButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) (frame.getContentPane().getLayout());
            cl.show(frame.getContentPane(), isAdmin ? "Admin" : "User");
        });

        bookPanel.add(bookLabel, BorderLayout.NORTH);
        bookPanel.add(scrollPane, BorderLayout.CENTER);
        bookPanel.add(backButton, BorderLayout.SOUTH);

        return bookPanel;
    }

    private static void updateBookList() {
        if (bookListTextArea != null) {
            bookListTextArea.setText("");
            for (Book book : books) {
                bookListTextArea.append(String.format("Title: %s\nAuthor: %s\nISBN: %s\nGenre: %s\nBook ID: %d\nAvailable: %d\n\n",
                        book.getTitle(), book.getAuthor(), book.getIsbn(), book.getGenre(), book.getQuantity(), book.getAvailable()));
            }
        }
    }

   private static JPanel createViewBooksPanel(JFrame frame) {
    JPanel viewBooksPanel = new JPanel(new BorderLayout());
    viewBooksPanel.setBackground(Color.decode("#f0f0f0")); // Light gray background

    JLabel viewBooksLabel = new JLabel("Available Books", JLabel.CENTER);
    viewBooksLabel.setFont(new Font("sanserrif", Font.BOLD, 20)); // Larger font

    bookListTextArea = new JTextArea(10, 40); // Initialize the JTextArea
    bookListTextArea.setEditable(false);
    updateBookList();

    JScrollPane scrollPane = new JScrollPane(bookListTextArea);

    JButton backButton = createStyledButton("Back");
    backButton.addActionListener(e -> {
        CardLayout cl = (CardLayout) (frame.getContentPane().getLayout());
        cl.show(frame.getContentPane(), "User");
    });

    // New buttons for borrowing and returning books
    JButton borrowBookButton = createStyledButton("Borrow Book");
    borrowBookButton.addActionListener(e -> {
    String bookTitle = JOptionPane.showInputDialog(frame, "Enter the title of the book you want to borrow:");
    if (bookTitle != null) {
        try {
            int quantityToBorrow = Integer.parseInt(JOptionPane.showInputDialog(frame, "Enter the quantity you want to borrow:"));
            for (Book book : books) {
                if (book.getTitle().equalsIgnoreCase(bookTitle)) {
                    if (book.getAvailable() >= quantityToBorrow) {
                        book.borrowBook(quantityToBorrow);
                        JOptionPane.showMessageDialog(frame, "Book(s) borrowed successfully!");
                        updateBookList();
                        return;
                    } else {
                        JOptionPane.showMessageDialog(frame, "Not enough copies available.");
                        return;
                    }
                }
            }
            JOptionPane.showMessageDialog(frame, "Book not found.");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid quantity input.");
        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(frame, ex.getMessage());
        }
    }
});

    JButton returnBookButton = createStyledButton("Return Book");
    returnBookButton.addActionListener(e -> {
    String bookTitle = JOptionPane.showInputDialog(frame, "Enter the title of the book you want to return:");
    if (bookTitle != null) {
        try {
            int quantityToReturn = Integer.parseInt(JOptionPane.showInputDialog(frame, "Enter the quantity you want to return:"));
            for (Book book : books) {
                if (book.getTitle().equalsIgnoreCase(bookTitle)) {
                    book.returnBook(quantityToReturn);
                    JOptionPane.showMessageDialog(frame, "Book(s) returned successfully!");
                    updateBookList();
                    return;
                }
            }
            JOptionPane.showMessageDialog(frame, "Book not found.");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid quantity input.");
        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(frame, ex.getMessage());
        }
    }
});


    JPanel buttonPanel = new JPanel();
    buttonPanel.add(borrowBookButton);
    buttonPanel.add(returnBookButton);
    buttonPanel.add(backButton);

    viewBooksPanel.add(viewBooksLabel, BorderLayout.NORTH);
    viewBooksPanel.add(scrollPane, BorderLayout.CENTER);
    viewBooksPanel.add(buttonPanel, BorderLayout.SOUTH);

    return viewBooksPanel;
}




    private static JPanel createManageLibraryPanel(JFrame frame) {
        JPanel manageLibraryPanel = new JPanel(new BorderLayout());
        manageLibraryPanel.setBackground(Color.decode("#7c0a02")); // Light gray background

        JLabel manageLibraryLabel = new JLabel("Manage Library", JLabel.CENTER);
        manageLibraryLabel.setFont(new Font("sanserrif", Font.BOLD, 20)); // Larger font

        JPanel buttonPanel = new JPanel();
        
        JButton browseButton = createStyledButton("Browse Book");
        JButton addBookButton = createStyledButton("Add Book");
        JButton removeBookButton = createStyledButton("Remove Book");
        JButton editBookButton = createStyledButton("Edit Book");
        JButton backButton = createStyledButton("Back");
        
        buttonPanel.add(browseButton);
        buttonPanel.add(addBookButton);
        buttonPanel.add(removeBookButton);
        buttonPanel.add(editBookButton);
        buttonPanel.add(backButton);

        manageLibraryPanel.add(manageLibraryLabel, BorderLayout.NORTH);
        manageLibraryPanel.add(buttonPanel, BorderLayout.CENTER);

        addBookButton.addActionListener(e -> {
            JPanel addPanel = new JPanel(new GridLayout(0, 1));
            addPanel.add(new JLabel("Title:"));
            JTextField titleField = new JTextField();
            addPanel.add(titleField);
            addPanel.add(new JLabel("Author:"));
            JTextField authorField = new JTextField();
            addPanel.add(authorField);
            addPanel.add(new JLabel("ISBN:"));
            JTextField isbnField = new JTextField();
            addPanel.add(isbnField);
            addPanel.add(new JLabel("Genre:"));
            JTextField genreField = new JTextField();
            addPanel.add(genreField);
            addPanel.add(new JLabel("Quantity:"));
            JTextField quantityField = new JTextField();
            addPanel.add(quantityField);
            addPanel.add(new JLabel("Available:"));
            JTextField availableField = new JTextField();
            addPanel.add(availableField);

            int result = JOptionPane.showConfirmDialog(frame, addPanel, "Add Book", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                try {
                    String title = titleField.getText();
                    String author = authorField.getText();
                    String isbn = isbnField.getText();
                    String genre = genreField.getText();
                    int quantity = Integer.parseInt(quantityField.getText());
                    int available = Integer.parseInt(availableField.getText());

                    books.add(new Book(title, author, isbn, genre, quantity, available));
                    updateBookList();
                    JOptionPane.showMessageDialog(frame, "Book added successfully!");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid input for quantity or available fields.");
                }
            }
        });
        
        browseButton.addActionListener(e -> {
            updateBookList();
            JOptionPane.showMessageDialog(frame, new JScrollPane(bookListTextArea), "List of Books", JOptionPane.PLAIN_MESSAGE);
        });

        removeBookButton.addActionListener(e -> {
            String bookTitle = JOptionPane.showInputDialog(frame, "Enter the title of the book to remove:");
            if (bookTitle != null) {
                books.removeIf(book -> book.getTitle().equalsIgnoreCase(bookTitle));
                updateBookList();
                JOptionPane.showMessageDialog(frame, "Book removed successfully!");
            }
        });

        editBookButton.addActionListener(e -> {
            String bookTitle = JOptionPane.showInputDialog(frame, "Enter the title of the book to edit:");
            if (bookTitle != null) {
                for (Book book : books) {
                    if (book.getTitle().equalsIgnoreCase(bookTitle)) {
                        JPanel editPanel = new JPanel(new GridLayout(0, 1));
                        editPanel.add(new JLabel("Title:"));
                        JTextField titleField = new JTextField(book.getTitle());
                        editPanel.add(titleField);
                        editPanel.add(new JLabel("Author:"));
                        JTextField authorField = new JTextField(book.getAuthor());
                        editPanel.add(authorField);
                        editPanel.add(new JLabel("ISBN:"));
                        JTextField isbnField = new JTextField(book.getIsbn());
                        editPanel.add(isbnField);
                        editPanel.add(new JLabel("Genre:"));
                        JTextField genreField = new JTextField(book.getGenre());
                        editPanel.add(genreField);
                        editPanel.add(new JLabel("Quantity:"));
                        JTextField quantityField = new JTextField(String.valueOf(book.getQuantity()));
                        editPanel.add(quantityField);
                        editPanel.add(new JLabel("Available:"));
                        JTextField availableField = new JTextField(String.valueOf(book.getAvailable()));
                        editPanel.add(availableField);

                        int result = JOptionPane.showConfirmDialog(frame, editPanel, "Edit Book", JOptionPane.OK_CANCEL_OPTION);
                        if (result == JOptionPane.OK_OPTION) {
                            try {
                                book.setTitle(titleField.getText());
                                book.setAuthor(authorField.getText());
                                book.setIsbn(isbnField.getText());
                                book.setGenre(genreField.getText());
                                book.setQuantity(Integer.parseInt(quantityField.getText()));
                                book.setAvailable(Integer.parseInt(availableField.getText()));

                                updateBookList();
                                JOptionPane.showMessageDialog(frame, "Book updated successfully!");
                            } catch (NumberFormatException ex) {
                                JOptionPane.showMessageDialog(frame, "Invalid input for quantity or available fields.");
                            }
                        }
                        return;
                    }
                }
                JOptionPane.showMessageDialog(frame, "Book not found.");
            }
        });

        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) (frame.getContentPane().getLayout());
            cl.show(frame.getContentPane(), "Admin");
        });

        return manageLibraryPanel;
    }
}
