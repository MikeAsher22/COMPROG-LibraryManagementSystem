class Book {
    private String title;
    private String author;
    private String isbn;
    private String genre;
    private int quantity;
    private int available;

    public Book(String title, String author, String isbn, String genre, int quantity, int available) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.genre = genre;
        this.quantity = quantity;
        this.available = available;
    }

    // Getter methods
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getGenre() {
        return genre;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getAvailable() {
        return available;
    }

    // Setter methods
    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setAvailable(int available) {
        this.available = available;
    }

    // Method to borrow books
    public void borrowBook(int quantityToBorrow) {
        if (quantityToBorrow > 0 && available >= quantityToBorrow) {
            available -= quantityToBorrow;
        } else {
            throw new IllegalStateException("Invalid quantity to borrow or not enough available copies.");
        }
    }

    // Method to return books
    public void returnBook(int quantityToReturn) {
        if (quantityToReturn > 0 && quantityToReturn <= available) {
            available += quantityToReturn; // Update available count directly
        } else {
            throw new IllegalStateException("Invalid quantity to return or quantity exceeds borrowed copies.");
        }
    }
    
}